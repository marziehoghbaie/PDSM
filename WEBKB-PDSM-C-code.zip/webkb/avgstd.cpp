#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <string> 
#include <math.h>
#include <conio.h>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
using namespace std;


	///reading vectors from file
void D(int n,string temp, double d1[])
{
	int i;
	for(i=1;i<n;i++)
{
	d1[i]=0;
}
string str,token1,token2;
istringstream isstemp(temp);
isstemp>>str;
isstemp>>str;
string delimiter = ":";
size_t pos = 0;
int k=0;
while(isstemp)
{
	while ((pos = str.find(delimiter)) != std::string::npos) {
    token1 = str.substr(0, pos);
    token2= str.substr(pos+1, pos+str.length());
    istringstream isstid(token1);
    istringstream issfr(token2);
    int tid;
	double fr;
    isstid>>tid;
    issfr>>fr;
    if(tid<n)
	d1[tid]=fr;
    str.erase(0, pos + delimiter.length());
}
	isstemp>>str;
}
}
int main(int argc, char** argv) {
	int NumberOfDocuments=4200;
	int NumberOfTerms=7773;
	int i=1;
//	ifstream file("DocumentMatrix.txt");
//	string str;
//	double terms[NumberOfTerms+1];
//	double st_term[NumberOfTerms+1];
//	for(i=0;i<NumberOfTerms+1;i++)
//	{
//		terms[i]=0;
//		st_term[i]=0;
//	}
//	
//	while(getline(file,str)){
//		istringstream iss(str);
//		int fr,termid,docid;
//		iss>>termid;
//		iss>>docid;
//		iss>>fr;
//		if(termid<NumberOfTerms+1)
//		terms[termid]+=fr;
//	}
////
////	for(i=1;i<NumberOfTerms+1;i++)
////	{
////		cout<<terms[i]<<" ";
////	}
//	ifstream f("DocFr.txt");
//	
//	i=1;
//	while(getline(f,str) && i<NumberOfTerms+1)
//	{
//		istringstream iss(str);
//		int docfr;
//		iss>>docfr;
//		terms[i]/=docfr;
//		i++;
//	}
//	ifstream f1("DocumentMatrix.txt");
//	i=1;
//	while(getline(f1,str))
//	{
//		istringstream iss(str);
//		int fr,termid,docid;
//		iss>>termid;
//		iss>>docid;
//		iss>>fr;
//		double x=0;
//		x=fr-terms[termid];
//		st_term[termid]+=x*x;	
//	}
//	
//		ifstream f2("DocFr.txt");
//	
//	i=1;
//	while(getline(f2,str) && i<NumberOfTerms+1)
//	{
//		istringstream iss(str);
//		int docfr;
//		iss>>docfr;
//		st_term[i]/=(docfr-1);
//		i++;
//	}
//	
//	
//	for(i=1;i<NumberOfTerms+1;i++)
//	{
//	st_term[i]=sqrt(st_term[i]);
//	}	
//	ofstream avg("avg.txt");
//	ofstream stdf("std.txt");
//	for(i=1;i<NumberOfTerms+1;i++)
//	{
//		avg<<i;
//		avg<<" ";
//		avg<<terms[i];
//		avg<<"\n";
//		stdf<<i;
//		stdf<<" ";
//		stdf<<st_term[i];
//		stdf<<"\n";
//	}
//	avg.close();
//	stdf.close();
	
	
//////////	create vector space model//

	std::ofstream vector("zscore.txt");
	string str;
	ifstream stdf("std.txt");
	ifstream avgf("avg.txt");
	double stdofterm[NumberOfTerms];
	double avg[NumberOfTerms];
	for(int j=0;j<NumberOfTerms;j++)
	{
		stdofterm[j]=avg[j]=0;
	}
	while(getline(stdf,str) && i<NumberOfTerms)
	{
		istringstream iss(str);
			int termid;
		iss>>termid;
		if(termid<NumberOfTerms)
			iss>>stdofterm[termid];
	}

		while(getline(avgf,str) && i<NumberOfTerms)
		{
		istringstream iss(str);
		int termid;
		iss>>termid;
		if(termid<NumberOfTerms)
		iss>>avg[termid];

		}


double *d[NumberOfDocuments];
for(i=0;i<NumberOfDocuments;i++)
{
	d[i]=new double[NumberOfTerms];
	for(int j=0;j<NumberOfTerms;j++)
	{
		d[i][j]=0;
	}
}

std::ifstream file("vector.txt");
string temp;
i=1;
while((i<NumberOfDocuments) && getline(file, temp))
{
	
D(NumberOfTerms,temp,d[i]);
i++;
}
file.close();
//
//for(i=1;i<NumberOfDocuments;i++)
//{
//		string temp;
//		int tid,docid,fr;
//		vector<<i;
//		vector<<" ";
//
//	for(int j=1;j<NumberOfTerms;j++)
//	{
//	if(d[i][j]!=0)
//	{
//		vector<<j;
//		vector<<":";
//			double tp=d[i][j]-avg[j];
//			if(stdofterm[j] != 0)
//			{
//				tp=tp/stdofterm[j];
//			}
//		vector<<tp;
//		vector<<" ";
//	
//	}
//	}vector<<"\n";
//	
//	
//}
//	vector.close();	

return 0;
}
