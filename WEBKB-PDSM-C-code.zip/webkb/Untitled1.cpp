///BBC
	for(i=1;i<NumberOfDocuments;i++)
	{
		if(cluster[k1][i]>=1 &&cluster[k1][i]<=510)
			lable[0]++;
			else if(cluster[k1][i]>=511 &&cluster[k1][i]<=896)
			lable[1]++;
			else if(cluster[k1][i]>=897 &&cluster[k1][i]<=1313)
			lable[2]++;
			else if(cluster[k1][i]>=1314 &&cluster[k1][i]<=1824)
			lable[3]++;
			else if(cluster[k1][i]>=1825 &&cluster[k1][i]<=2225)
			{
				lable[4]++; 
			}
	}
	
//BBCSPORT
//	for(i=1;i<NumberOfDocuments;i++)
//	{
//		if(cluster[k1][i]>=1 &&cluster[k1][i]<=101)
//			lable[0]++;
//			else if(cluster[k1][i]>=102 &&cluster[k1][i]<=225)
//			lable[1]++;
//			else if(cluster[k1][i]>=226 &&cluster[k1][i]<=490)
//			lable[2]++;
//			else if(cluster[k1][i]>=491 &&cluster[k1][i]<=637)
//			lable[3]++;
//			else if(cluster[k1][i]>=638 &&cluster[k1][i]<=737)
//			{
//				lable[4]++; 
//			}
//	}
