#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <string> 
#include <math.h>
#include <conio.h>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
using namespace std;


	///reading vectors from file
void D(int n,string temp, double d1[])
{
	int i;
	for(i=1;i<n;i++)
{
	d1[i]=0;
}
string str,token1,token2;
istringstream isstemp(temp);
isstemp>>str;
isstemp>>str;
string delimiter = ":";
size_t pos = 0;
int k=0;
while(isstemp)
{
	while ((pos = str.find(delimiter)) != std::string::npos) {
    token1 = str.substr(0, pos);
    token2= str.substr(pos+1, pos+str.length());
    istringstream isstid(token1);
    istringstream issfr(token2);
    int tid;
	double fr;
    isstid>>tid;
    issfr>>fr;
    if(tid<n)
	d1[tid]=fr;
    str.erase(0, pos + delimiter.length());
}
	isstemp>>str;
}
}


double Vsize(double vector[],int NumberOfTerms)
{
	double temp=0;
	int i=0;

	for(i=1;i<NumberOfTerms;i++)
{
	temp+=vector[i]*vector[i];
}
double vectorize=sqrt(temp);
return vectorize;
}

int main(int argc, char** argv) {
	int NumberOfDocuments=4200;
	int NumberOfTerms=7773;
	int i=1;

double *d[NumberOfDocuments];
for(i=0;i<NumberOfDocuments;i++)
{
	d[i]=new double[NumberOfTerms];
	for(int j=0;j<NumberOfTerms;j++)
	{
		d[i][j]=0;
	}
}
std::ifstream file("vector_TF_IDF.txt");
std::ofstream vector("length_normalizedvector_TF_IDF.txt");
string temp;
i=1;
while((i<NumberOfDocuments) && getline(file, temp))
{
	
D(NumberOfTerms,temp,d[i]);
i++;
}
file.close();

double length[NumberOfDocuments];
for(int i=1;i<NumberOfDocuments;i++)
{
	length[i]=0;
	length[i]=Vsize(d[i],NumberOfTerms);
}


for(i=1;i<NumberOfDocuments;i++)
{
		string temp;
		int tid,docid,fr;
		vector<<i;
		vector<<" ";

	for(int j=1;j<NumberOfTerms;j++)
	{
	if(d[i][j]!=0)
	{
		vector<<j;
		vector<<":";
		double tp=d[i][j]/length[i];
		vector<<tp;
		vector<<" ";
	
	}
	}vector<<"\n";
	
	
}
	vector.close();	

return 0;
}
