#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <string> 
#include <math.h>
#include <conio.h>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


//////webkb/////////

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

///reading vectors from file
void D(int n,string temp, double d1[])
{
	int i;
	for(i=1;i<n;i++)
{
	d1[i]=0;
}
string str,token1,token2;
istringstream isstemp(temp);
isstemp>>str;
isstemp>>str;
string delimiter = ":";
size_t pos = 0;
int k=0;
while(isstemp)
{
	while ((pos = str.find(delimiter)) != std::string::npos) {
    token1 = str.substr(0, pos);
    token2= str.substr(pos+1, pos+str.length());
    istringstream isstid(token1);
    istringstream issfr(token2);
    int tid;
	double fr;
    isstid>>tid;
    issfr>>fr;
    if(tid<n)
	d1[tid]=fr;
    str.erase(0, pos + delimiter.length());
}
	isstemp>>str;
}
}


double Vsize(double vector[],int NumberOfTerms)
{
	double temp=0;
	int i=0;

	for(i=1;i<NumberOfTerms;i++)
{
	temp+=vector[i]*vector[i];
}
double vectorize=sqrt(temp);
return vectorize;
}

///cosine similarity_distance///
double CosineDistance(double d1[], double d2[], int n){
int i=0;
double d1size=Vsize(d1, n);
double d2size=Vsize(d2, n);
double result=0;
for(i=0;i<n;i++)
{
	result+=d1[i]*d2[i];
}
double sizeofvectors=d1size*d2size;
result=result/sizeofvectors;

return result;
}
/////////////////////////////////

///manhattan distance///
double ManhattanDistance(double d1[], double d2[], int n)
{
	int i;
	double distance=0;
for(i=1;i<n;i++)
{
	double temp=(d1[i]-d2[i]);
	if(temp<0)
	temp=temp*(-1);
	distance+=temp;
}
return distance;
}
////////////////////////////////

///euclidean distance///
double EuclideanDistance(double d1[], double d2[], double n)
{
int i;
double distance=0;

for(i=1;i<n;i++)
{

	double temp=(d1[i]-d2[i]);
	distance+=temp*temp;
}

distance=sqrt(distance);
return distance;
}
//////////////////////////////

///Chebyshev Distance///
double ChebyshevDistance(double d1[], double d2[], int n){
int i;
double result=-1;
for(i=1;i<n;i++)
{
	double temp=fabs(d1[i]-d2[i]);
	if(temp>result){
		result=temp;
	}
}
return result;
}
/////////////////////////////////

///return number of non-zero features
int NU(double d1[], int n)
{
	int result=0;
	int i;
	for(i=1;i<n;i++)
	{
		if(d1[i]!=0)
		{
		result++;
		}
	}
	return result;
}
////////////////////////////////////


int sumofarray(double d[], int n){
	int i=0;
	int result=0;
	for(i=1;i<n;i++)
	{
		result+=(d[i]);
	}
	return result;
}
//d1 , d2 based on tf
double IT_SIM(double DF[],double d1[], double d2[], int n){
	double result=0; 
	int i,j;
	double A, B, pd1t, pd2t;
//	double sd1,sd2;
//	sd1=Vsize(d1,n);
//	sd2=Vsize(d2,n);
	A=B=0;
	for(i=1;i<n;i++)
	{
		pd1t=(d1[i]);
		pd2t=(d2[i]);
		double minimum=min(pd1t,pd2t);
		A+=minimum*(log10(DF[i]));
		B+=(pd1t+pd2t)*(log10(DF[i]));
	}
	result=2*(A/B);
	return result;
}

void sumarray(double d1[],double d2[], int n)
{
	for(int i=0;i<n;i++)
	{	
			d1[i]+=d2[i];
	}
	}


///mysim 

///mysim 

double mysim(double d1[], double d2[], int n){
int i=0;
//double d1size=Vsize(d1, n);
//double d2size=Vsize(d2, n);
double PR=0;
double intersect=0;
double result=0;
for(i=0;i<n;i++)
{
	if(d1[i]!=0 && d2[i]!=0){
		result+=d1[i]*d2[i];
		intersect++;
	}
	else if((d1[i]!=0&&d2[i]==0)||(d1[i]==0&&d2[i]!=0))
	PR++;
}
//double sizeofvectors=d1size*d2size;
//result=result/sizeofvectors;
double dissimilarity;
if(intersect==0)
intersect++;
if(PR==0)
PR++;
dissimilarity=(intersect/PR);

dissimilarity=(dissimilarity)*(result);
return dissimilarity;
}

double mysim2(double d1[], double d2[], int n){
double result,A=0,B=0;
int i=0;
for(i=0;i<n;i++)
{
	A+=d1[i]*d2[i];
	B+=fabs(d1[i]-d2[i]);
}
result=A/B;
return result;
}

int search(int a[], int l, int x)
{
	int result=0;
	int i=1;
	while(i<l && result!=1)
	{
		if(a[i]==x && a[i]!=0 && x!=0)
		result=1;
		i++;
	}
	return result;
}


double EJ(double d1[], double d2[],int n){
	double d12=0 , result=0;
	int i=0;
	double d22=0,d11=0, temp;
	for(i=0; i<n;i++)
	{
		d11+=d1[i]*d1[i];
		d22+=d2[i]*d2[i];
		d12+=d1[i]*d2[i];
	}
	temp=d11+d22-d12;
	result=d12/temp;
	return result;
	
}
 double J(double d1[], double d2[],int n){
	double result=0; 
	int i,j;
	double A, B;
	A=B=0;
	for(i=0;i<n;i++)
	{
		A+=min(d1[i],d2[i]);
		B+=max(d1[i],d2[i]);;
	}
	result=(A/B);
	return result;
}
double DSM(double d1[], double d2[], int n){
	double result=0; 
	int i,j, abc=0;
	double intersect=0, PR=0;
	double A, B, pd1t, pd2t;
//	double sd1,sd2;
//	sd1=Vsize(d1,n);
//	sd2=Vsize(d2,n);
	A=B=0;
	for(i=0;i<n;i++)
	{
		pd1t=(d1[i]);
		pd2t=(d2[i]);
		double minimum=min(pd1t,pd2t);
		A+=minimum;
		B+=max(pd1t,pd2t);
			if(d1[i]!=0 && d2[i]!=0)
	{
		intersect++;
	}
	else if(d1[i]==0 && d2[i]==0)
	abc++;

	}
	intersect++;
	double x=n-abc-1;
	
	result=(A/B)*(intersect/x);
	return result;
}



int main(int argc, char** argv) {
	int NumberOfDocuments=4200;
	int NumberOfTerms=7773;
	int i=1,j=0;
	string str;
//ifstream docfrfile("DocFr.txt");
//double DF[NumberOfTerms];
//while(getline(docfrfile,str) && i<NumberOfTerms)
//{
//	istringstream iss(str);
//	iss>>DF[i];
//	i++;
//}

double *d[NumberOfDocuments];
for(i=0;i<NumberOfDocuments;i++)
{
	d[i]=new double[NumberOfTerms];
	for(j=0;j<NumberOfTerms;j++)
	{
		d[i][j]=0;
	}
}

int classnumber=4;
int classlable[classnumber][NumberOfDocuments];
//1 student
//2 project
//3 faculty
//4 course


for(i=0;i<classnumber;i++)
{
	for(j=1;j<NumberOfDocuments;j++)
{
	classlable[i][j]=0;
}
}
ifstream classfile("class.txt");
int c[classnumber];
string realclass[classnumber]={"student","project","faculty","course"};

for(int x=0;x<classnumber;x++)
c[x]=1;


while(getline(classfile,str))
{
	string temp;
	int docid;
istringstream iss(str);
iss>>docid;
iss>>temp;
for(int x=0;x<classnumber;x++)
{
		if(temp==realclass[x] && c[x]<NumberOfDocuments)
	{
	classlable[x][c[x]]=docid;
	c[x]++;
	}
}
}

//
double avg_time=0;
std::ifstream file("vector.txt");
string temp;
i=1;
while((i<NumberOfDocuments) && getline(file, temp))
{
D(NumberOfTerms,temp,d[i]);
i++;
}
file.close();
ofstream resfile("DSM-tf.txt");
int clusteriteration=0;

	for(clusteriteration=15;clusteriteration<16;clusteriteration+=5)
	{
cout<<"clusteriteration"<<clusteriteration<<endl;
int q=0;
double accuracy=0, entr=0;
/////k-means clustering
////numberof clusters///////////////////////////////////////////////////////
int K=clusteriteration;
int k;
int centroid[NumberOfDocuments];
double *u[K];

	for(k=0;k<K;k++)
	{
	u[k]=new double[NumberOfTerms];
	for(j=0;j<NumberOfTerms;j++)
		{
		u[k][j]=0;
		}
	}


double tempdistance;
int sizeofcluster[K];
bool changed[NumberOfDocuments];
								
	for(q=0;q<5;q++){
			double scnd = 0;
clock_t begin = clock();

			double En=0;
		for(i=1;i<NumberOfDocuments;i++)
		centroid[i]=-1;
	
	///set center of every cluster
k=0;

	while(k<K)
{	
	int r;
	int t=(int)rand()%(NumberOfDocuments+1);
	srand(time(0)^t);
	r=(int)rand()%(NumberOfDocuments-1);
	for(i=1;i<NumberOfTerms;i++)
	{
	if((r+1)<NumberOfDocuments && k<K)
	{
	u[k][i]=d[r+1][i];
	}	
	}
	k++;
}

bool continuee=true;
int mm=0;
while(continuee){
	
	for(k=0;k<K;k++)
	sizeofcluster[k]=0;
	
	int lastcentroid[NumberOfDocuments];
	for(i=1;i<NumberOfDocuments;i++)
	{
		lastcentroid[i]=centroid[i];
	}
// first iteration 
for(i=1;i<NumberOfDocuments;i++)
{
	//dissimilarity calculation
	tempdistance= -1;
	for(k=0;k<K;k++)
	{
		double dis=DSM(u[k],d[i],NumberOfTerms);
//		double dis=EuclideanDistance(u[k],d[i],NumberOfTerms);
//		double dis=ManhattanDistance(u[k],d[i],NumberOfTerms);
//		double dis=CosineDistance(u[k],d[i],NumberOfTerms);
//		double dis=EJ(u[k],d[i],NumberOfTerms);
		
		
		if(tempdistance < dis)
		{
			centroid[i]=k;
			tempdistance=dis;
		}
	}
}
// second iteration
for(k=0;k<K;k++)
for(j=0;j<NumberOfTerms;j++)
{
	u[k][j]=0;
}

for(i=1;i<NumberOfDocuments;i++)
{
	for(k=0;k<K;k++)
	{
		if(centroid[i]==k)
		{
			sizeofcluster[k]++;
			sumarray(u[k],d[i],NumberOfTerms);
		}
	}
}

for(k=0;k<K;k++)
{
//cout<<k<<" "<<sizeofcluster[k]<<endl;
	for(i=1;i<NumberOfTerms;i++)
{	
	if(sizeofcluster[k]!=0)
	u[k][i]/=sizeofcluster[k];
}

}

double x=0;
for(int h=1;h<NumberOfDocuments;h++)
{
	x+=fabs(lastcentroid[h]-centroid[h]);
}
x/=(NumberOfDocuments-1);
mm++;
if(x<0.00000001 || mm>30)
continuee=false;
}

j=1;
int cluster[K][NumberOfDocuments];
for(k=0;k<K;k++)
	for(i=1;i<NumberOfDocuments;i++)
{
	cluster[k][i]=-1;	
}

for(i=1;i<NumberOfDocuments;i++)
{
	for(k=0;k<K;k++)
	{
	if(centroid[i]==k && j<NumberOfDocuments)
	{
		cluster[k][j]=i;
		j++;
	}	
	}
}
	double ni[K];
	
for(k=0;k<K;k++)
	ni[k]=0;
	
	for(i=1;i<NumberOfDocuments;i++)
{
	if(centroid[i]<K)
	{
	ni[centroid[i]]++;
	}
}


int max[K];
for(k=0;k<K;k++)
max[k]=-1;

for(int k1=0;k1<K;k1++){


	int lable[classnumber];
	for(int m=0;m<classnumber;m++)
	lable[m]=0;
	
		for(i=1;i<NumberOfDocuments;i++)
	{
		if(cluster[k1][i]!=0)
		{
				for(int x=0;x<classnumber;x++)
				{
				if(search(classlable[x], NumberOfDocuments, cluster[k1][i])==1)
					{
				lable[x]++;
					}
				}
		}
	}
	for(int m=0;m<classnumber;m++)
	{
		if(lable[m]>max[k1])
		{
		max[k1]=lable[m];
		}

	}

///////entropy/////
	double temp_En=0;

		for(int m=0;m<classnumber;m++)
		{
		if(lable[m]!=0)
		{
			temp_En+=(-1)*(lable[m]/ni[k1])*log10(lable[m]/ni[k1]);
		}
		}
	temp_En=temp_En*ni[k1];	
	En+=temp_En;

}
double result=0;

for(k=0;k<K;k++){
	result+=max[k];
}
/////bayad number of doc ro -1 koni 

result/=(NumberOfDocuments-1);
En=En/((log10(classnumber))*(NumberOfDocuments-1));
    	accuracy+=result;
    	entr+=En;
    	clock_t end = clock();
scnd= (double)(end - begin) / CLOCKS_PER_SEC;
    	avg_time+=scnd;
cout<<"q = "<<q<<"Accuracy "<<result<<" , Entropy "<<En<<endl;
resfile<<"q = "<<q<<"Accuracy "<<result<<" , Entropy "<<En<<" time "<<scnd<<endl;
}
resfile<<"\n";
resfile<<"clusteriteration = "<<clusteriteration<<"accuracy "<<(accuracy/5.0)<<" EN"<<entr/5.0<<avg_time/5.0<<endl;
}
	return 0;
}



