#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <string> 
#include <math.h>
#include <conio.h>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>



using namespace std;
bool search(string dictionary[], int l, string temp)
{
	int i=0;
	bool result=false;
	while(!result && i<l)
	{
		if(dictionary[i]==temp)
		result=true;
		i++;
	}
	return result;
}
int termFrequency(string str, string term)
{
	
	int fr=0;
istringstream iss(str);
string temp;
iss>>temp;
while(iss)	{
	if(temp==term)
	fr++;
	iss>>temp;
}
	return fr;
	
}

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	int NumberOfDocuments=5485;
	int NumberOfTerms=17388;

int i=1,j=0;
	string str;
string *dictionary;
	dictionary=new string[NumberOfTerms];
	while(j<NumberOfTerms)
	{
		dictionary[j]="";
		j++;
	}


ifstream dict("dictionary.txt");
ofstream matrix("train-matrix.txt");
	j=1;
while(getline(dict,str) && j<NumberOfTerms)
{
	istringstream iss(str);
	string temp;
	iss>>temp;
	iss>>dictionary[j];
	j++;
}
j=1;
int fr=0;
int docid=1;
while(j<NumberOfTerms){
fr=0;
docid=1;
ifstream docfile("documents-train.txt");
	while(getline(docfile, str))
{
	fr=termFrequency(str,dictionary[j]);
	if(fr!=0)
	{
		matrix<<j;
		matrix<<" ";
		matrix<<docid;
		matrix<<" ";
		matrix<<fr;
		matrix<<"\n";
	}
	docid++;
}
j++;
}

	return 0;
}

