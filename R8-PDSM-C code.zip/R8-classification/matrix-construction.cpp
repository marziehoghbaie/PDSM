#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <string> 
#include <math.h>
#include <conio.h>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>



using namespace std;
bool search(string dictionary[], int l, string temp)
{
	int i=0;
	bool result=false;
	while(!result && i<l)
	{
		if(dictionary[i]==temp)
		result=true;
		i++;
	}
	return result;
}
int termFrequency(string str, string term)
{
	
	int fr=0;
istringstream iss(str);
string temp;
iss>>temp;
while(iss)	{
	if(temp==term)
	fr++;
	iss>>temp;
}
	return fr;
	
}

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	int NumberOfDocuments=2189;
	int NumberOfTerms=17388;

int i=1,j=0;
	string str;
	std::ofstream vector("vector-test.txt");
	for(i=1;i<=NumberOfDocuments;i++){
	std::ifstream file("test-matrix.txt");
	
		string temp;
		int tid,docid,fr;
vector<<i;
vector<<" ";
		while(std::getline(file, temp))
{
	std::istringstream iss(temp);
	iss >> tid;
	iss >> docid;
	iss >> fr;
	if(docid==i)
	{
		vector<<tid;
		vector<<":";
		vector<<fr;
		vector<<" ";
		
	}
	
}
vector<<"\n";
	file.close();
	}
	vector.close();	
	///

	return 0;
}

