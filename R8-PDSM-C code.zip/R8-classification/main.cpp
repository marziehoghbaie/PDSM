#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <string> 
#include <math.h>
#include <conio.h>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


//////R8/////////

using namespace std;

int termFrequency(string str, string term)
{
	
	int fr=0;
istringstream iss(str);
string temp;
iss>>temp;
while(iss)	{
	if(temp==term)
	fr++;
	iss>>temp;
}
	return fr;
	
}


//////webkb/////////

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

///reading vectors from file
void D(int n,string temp, double d1[])
{
	int i;
	for(i=1;i<n;i++)
{
	d1[i]=0;
}
string str,token1,token2;
istringstream isstemp(temp);
isstemp>>str;
isstemp>>str;
string delimiter = ":";
size_t pos = 0;
int k=0;
while(isstemp)
{
	while ((pos = str.find(delimiter)) != std::string::npos) {
    token1 = str.substr(0, pos);
    token2= str.substr(pos+1, pos+str.length());
    istringstream isstid(token1);
    istringstream issfr(token2);
    int tid;
	double fr;
    isstid>>tid;
    issfr>>fr;
    if(tid<n)
	d1[tid]=fr;
    str.erase(0, pos + delimiter.length());
}
	isstemp>>str;
}
}


double Vsize(double vector[],int NumberOfTerms)
{
	double temp=0;
	int i=0;

	for(i=1;i<NumberOfTerms;i++)
{
	temp+=vector[i]*vector[i];
}
double vectorize=sqrt(temp);
return vectorize;
}

///cosine similarity_distance///
double CosineDistance(double d1[], double d2[], int n){
int i=0;
setprecision(9);
double d1size=Vsize(d1, n);
double d2size=Vsize(d2, n);
double result=0;
for(i=0;i<n;i++)
{
	result+=d1[i]*d2[i];
}
double sizeofvectors=d1size*d2size;
result=result/sizeofvectors;

return result;
}
/////////////////////////////////

///manhattan distance///
double ManhattanDistance(double d1[], double d2[], int n)
{
	int i;
	double distance=0;
for(i=1;i<n;i++)
{
	double temp=(d1[i]-d2[i]);
	if(temp<0)
	temp=temp*(-1);
	distance+=temp;
}
return distance;
}
////////////////////////////////

///euclidean distance///
double EuclideanDistance(double d1[], double d2[], double n)
{
int i;
double distance=0;

for(i=1;i<n;i++)
{
if(d1[i]!=0 || d2[i]!=0){
	
	double temp=(d1[i]-d2[i]);
	distance+=temp*temp;
}
}

distance=sqrt(distance);
return distance;
}
//////////////////////////////

///Chebyshev Distance///
double ChebyshevDistance(double d1[], double d2[], int n){
int i;
double result=-1;
for(i=1;i<n;i++)
{
	double temp=fabs(d1[i]-d2[i]);
	if(temp>result){
		result=temp;
	}
}
return result;
}
/////////////////////////////////

///return number of non-zero features
int NU(double d1[], int n)
{
	int result=0;
	int i;
	for(i=1;i<n;i++)
	{
		if(d1[i]!=0)
		{
		result++;
		}
	}
	return result;
}
////////////////////////////////////


int sumofarray(double d[], int n){
	int i=0;
	int result=0;
	for(i=1;i<n;i++)
	{
		result+=(d[i]);
	}
	return result;
}
//d1 , d2 based on tf
double IT_SIM(double DF[],double d1[], double d2[], int n){
	double result=0; 
	int i,j;
	double A, B, pd1t, pd2t;
	int sd1,sd2;
//	sd1=Vsize(d1,n);
//	sd2=Vsize(d2,n);
	A=B=0;
	for(i=1;i<n;i++)
	{
		pd1t=(d1[i]);
		pd2t=(d2[i]);
		double minimum=min(pd1t,pd2t);
		A+=minimum*(log10(DF[i]));
		B+=(pd1t+pd2t)*(log10(DF[i]));
	}
	result=2*(A/B);
	return result;
}

void sumarray(double d1[],double d2[], int n)
{
	for(int i=0;i<n;i++)
	{	
			d1[i]+=d2[i];
	}
	}


///mysim 

///mysim 

double mysim(double d1[], double d2[], int n){
int i=0;
double d1size=Vsize(d1, n);
double d2size=Vsize(d2, n);
double PR=0;
double intersect=0;
double result=0;
for(i=0;i<n;i++)
{
	if(d1[i]!=0 && d2[i]!=0){
//		cout<<d1[i]<<" "<<d2[i];
		result+=d1[i]*d2[i];
		intersect++;
	}
	else if((d1[i]!=0&&d2[i]==0)||(d1[i]==0&&d2[i]!=0))
	PR++;
}
double sizeofvectors=d1size*d2size;
result=result/sizeofvectors;
double dissimilarity=result;
//cout<<PR<<" "<<intersect<<endl;

if(intersect==0)
intersect++;
if(PR==0)
PR++;
dissimilarity=(intersect/PR);

dissimilarity=(dissimilarity)*(result);
return dissimilarity;
}

double mysim2(double d1[], double d2[], int n){
double result,A=0,B=0;
int i=0;
for(i=0;i<n;i++)
{
	A+=d1[i]*d2[i];
	B+=fabs(d1[i]-d2[i]);
}
result=A/B;
return result;
}

int search(int a[], int l, int x)
{
	int result=0;
	int i=1;
	while(i<l && result!=1)
	{
		if(a[i]==x && a[i]!=0 && x!=0)
		result=1;
		i++;
	}
	return result;
}



double EJ(double d1[], double d2[],int n){
	setprecision(9);
	double d12=0 , result=0, d22=0,d11=0, temp;
	for(int i=1; i<n;i++)
	{
		d11+=d1[i]*d1[i];
		d22+=d2[i]*d2[i];
		d12+=d1[i]*d2[i];
	}
	temp=d11+d22-d12;
	result=d12/temp;
	return result;
	
}

 double J(double d1[], double d2[],int n){
	double result=0; 
	int i,j;
	double A, B;
	A=B=0;
	for(i=0;i<n;i++)
	{
		A+=min(d1[i],d2[i]);
		B+=max(d1[i],d2[i]);;
	}
	result=(A/B);
	return result;
}


double DSM(double d1[], double d2[], int n){
	double result=0; 
	int i,j, abc=0;
	double intersect=0, PR=0;
	double A, B, pd1t, pd2t;
//	double sd1,sd2;
//	sd1=Vsize(d1,n);
//	sd2=Vsize(d2,n);
	A=B=0;
	for(i=0;i<n;i++)
	{
		pd1t=(d1[i]);
		pd2t=(d2[i]);
		double minimum=min(pd1t,pd2t);
		A+=minimum;
		B+=max(pd1t,pd2t);
			if(d1[i]!=0 && d2[i]!=0)
	{
		intersect++;
	}
	else if(d1[i]==0 && d2[i]==0)
	abc++;

	}
	intersect++;
	double x=n-abc-1;
	
	result=(A/B)*(intersect/x);
	return result;
}


string max_class(string inp[],int k)
{
//1 acq
//2 crude
//3 earn
//4 grain
//5 interest
//6 money-fx	
//7 ship
//8 trade

	string result="";
	int fr[8];
	for(int j=0;j<8;j++){
		fr[j] = 0;
	}
	for(int i=0;i<k;i++){
	if(inp[i]=="acq")
	fr[0]++;
	else if(inp[i]=="crude")
	fr[1]++;
	else if(inp[i]=="earn")
	fr[2]++;
	else if(inp[i]=="grain")
	fr[3]++;
	else if(inp[i]=="interest")
	fr[4]++;
	else if(inp[i]=="money-fx")
	fr[5]++;
	else if(inp[i]=="ship")
	fr[6]++;
	else if(inp[i]=="trade")
	fr[7]++;
	
	}
	int max=fr[0];
	int pos=0;
	
	for(int j=1;j<8;j++){
		if(max<fr[j])
		{
			max=fr[j];
			pos=j;
		}
	}
//	cout<<"fr "<<fr[pos]<<" dasdasd"<<endl;
	if(pos==0)
	result="acq";
	else if(pos==1)
	result="crude";
	else if(pos==2)
	result="earn";
	else if(pos==3)
	result="grain";
	else if(pos==4)
	result="interest";
	else if(pos==5)
	result="money-fx";
	else if(pos==6)
	result="ship";
	else if(pos==7)
	result="trade";
//	cout<<" pos "<<pos<<"max "<<max<<" "<<endl;
	return result;
}


int main(int argc, char** argv) {

	int TestN=2190;
	int TrainN=5486;
	int NumberOfTerms=17388;
	int i,j;
	string str;
double *TestDoc[TestN];
double *TrainDoc[TrainN];

string ctest[TestN],ctrain[TrainN];

for(int h=0;h<TestN;h++)
{
	ctest[h]="";
}
for(int h=0;h<TrainN;h++)
{
	ctrain[h]="";
}
ifstream classfile("class-test.txt");

while(getline(classfile,str))
{
	string temp;
	int docid;
istringstream iss(str);
iss>>docid;
iss>>temp;
if(docid<TestN && docid>0)
ctest[docid]=temp;
}
ifstream classfile2("class-train.txt");

while(getline(classfile2,str))
{
	string temp;
	int docid;
istringstream iss(str);
iss>>docid;
iss>>temp;
if(docid<TrainN && docid>0)
ctrain[docid]=temp;
}


for(i=0;i<TestN;i++)
{
	TestDoc[i]=new double[NumberOfTerms];
	for(j=0;j<NumberOfTerms;j++)
	{
		TestDoc[i][j]=0;
	}
}
////////////////////////////////////////
for(i=0;i<TrainN;i++)
{
	TrainDoc[i]=new double[NumberOfTerms];
	for(j=0;j<NumberOfTerms;j++)
	{
		TrainDoc[i][j]=0;
	}
}
////////////////////////////////////
std::ifstream file("vector-test-tf-idf-normal.txt");
string temp;
i=1;
while((i<TestN) && getline(file, temp))
{

D(NumberOfTerms,temp,TestDoc[i]);
i++;
}
file.close();
///////////////////////////////////////////
std::ifstream file2("vector-train-normal-tf-idf.txt");
i=1;
while((i<TrainN) && getline(file2, temp))
{
D(NumberOfTerms,temp,TrainDoc[i]);
i++;
}
file2.close();
//////////////////////////////////////////////

ofstream resfile("EJ-tf-idf-normal.txt");

int k=1;
i=0;
	for(k=1;k<16;k+=2){
		
cout<<"k "<<k<<endl;

string cal_class[TestN];
for(int dd=0;dd<TestN;dd++)
cal_class[dd]="";

for(i=1;i<TestN;i++)
{
//cout<<i<<endl;
/////////////////////////
string nearest_neighbour_class[k];
double score[k];
for(int m=0;m<k;m++)
{
	score[m] = -1;
	nearest_neighbour_class[m]="";
}
/////////////////////////
for(j = 1 ; j < TrainN ; j++){
	
	double measure=EJ(TestDoc[i],TrainDoc[j],NumberOfTerms);
	 
	 double maxim=score[0];
	 int position=0;
	 for(int y=1;y<k;y++)
		{
			if(score[y] < maxim)
			{
				maxim=score[y];
				position=y;
			}
		}
	if(measure > maxim)
	{
if(position<k && j<TrainN && j>0)
{
	score[position]=measure;
	nearest_neighbour_class[position]=ctrain[j];
//	cout<<i<<" "<<j<<" "<<measure<<" "<<maxim<<	" "<<nearest_neighbour_class[position]<<endl;
}
	}
}
cal_class[i]=max_class(nearest_neighbour_class,k);
//cout<<"docid :"<<i<<" "<<cal_class[i]<<endl;
}

//////Accuracy////////
double accuracy=0;
for(int e=1;e<TestN;e++)
{
//cout<<"docid "<<e<<" "<<cal_class[e]<<" "<<ctest[e]<<endl;
	if(cal_class[e]==ctest[e])
	{
		accuracy++;
	}
}
accuracy=accuracy/(TestN-1); 
resfile<<"k= "<<k<<"accuracy "<<accuracy<<endl;
cout<<"accuracy "<<accuracy<<endl;
}


	return 0;
}


